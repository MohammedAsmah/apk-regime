# =============================
# IMPORTS
# =============================
import os
import re
import PyPDF2
import pandas as pd

from langchain.schema import Document
from langchain_ollama import OllamaEmbeddings
from langchain_chroma import Chroma
from langchain_groq import ChatGroq


# =============================
# CONFIGURATION
# =============================
DATA_DIR = "test_data"
VECTOR_DIR = "./dbVector"

OLLAMA_URL = "http://localhost:11434"
OLLAMA_MODEL = "nomic-embed-text"

GROQ_API_KEY ="YOUR API"
GROQ_MODEL = "meta-llama/llama-4-maverick-17b-128e-instruct"


# =============================
# INGESTION FUNCTIONS
# =============================

def ingest_pdf(path):
    reader = PyPDF2.PdfReader(path)
    text = ""
    for page in reader.pages:
        if page.extract_text():
            text += page.extract_text() + " "
    return [Document(page_content=text.strip(), metadata={"source": path, "type": "pdf"})]


def ingest_txt(path):
    with open(path, "r", encoding="utf-8") as f:
        text = f.read()
    return [Document(page_content=text.strip(), metadata={"source": path, "type": "txt"})]


def ingest_csv(path):
    df = pd.read_csv(path)
    docs = []
    for _, row in df.iterrows():
        text = " | ".join([f"{col}: {row[col]}" for col in df.columns])
        docs.append(Document(page_content=text, metadata={"source": path, "type": "csv"}))
    return docs


# =============================
# AUTO INGESTION (KEY PART)
# =============================

def ingest_all_sources(base_dir):
    all_docs = []

    for root, _, files in os.walk(base_dir):
        for file in files:
            path = os.path.join(root, file)

            if file.lower().endswith(".pdf"):
                all_docs.extend(ingest_pdf(path))

            elif file.lower().endswith(".txt"):
                all_docs.extend(ingest_txt(path))

            elif file.lower().endswith(".csv"):
                all_docs.extend(ingest_csv(path))

    return all_docs


# =============================
# CLEANING
# =============================

def clean_text(text):
    text = re.sub(r"\n+", " ", text)
    text = re.sub(r"\s{2,}", " ", text)
    return text.strip()


def clean_documents(docs):
    cleaned = []
    for d in docs:
        cleaned.append(
            Document(
                page_content=clean_text(d.page_content),
                metadata=d.metadata
            )
        )
    return cleaned


# =============================
# CHUNKING
# =============================

def chunk_text(text, size=500, overlap=50):
    chunks = []
    start = 0
    while start < len(text):
        end = start + size
        chunk = text[start:end].strip()
        if chunk:
            chunks.append(Document(page_content=chunk))
        start += size - overlap
    return chunks


def chunk_documents(docs):
    all_chunks = []
    for d in docs:
        all_chunks.extend(chunk_text(d.page_content))
    return all_chunks


# =============================
# VECTOR DATABASE
# =============================

def build_vector_db(chunks):
    embeddings = OllamaEmbeddings(
        base_url=OLLAMA_URL,
        model=OLLAMA_MODEL
    )

    db = Chroma(
        persist_directory=VECTOR_DIR,
        embedding_function=embeddings
    )

    db.add_documents(chunks)
    return db


# =============================
# LLM
# =============================

def load_llm():
    return ChatGroq(
        api_key=GROQ_API_KEY,
        model=GROQ_MODEL
    )


# =============================
# Q&A
# =============================

def ask_question(question, llm, db):
    docs = db.similarity_search(question, k=4)
    context = "\n".join([d.page_content for d in docs])

    prompt = f"""
Tu es un assistant nutritionnel.
Réponds uniquement avec les informations du contexte.

Contexte :
{context}

Question :
{question}
"""

    response = llm.invoke(prompt)
    return response.content


# =============================
# MAIN
# =============================

def main():
    print("\n Chargement automatique des données...")
    docs = ingest_all_sources(DATA_DIR)

    if not docs:
        print(" Aucun document trouvé")
        return

    print(f" {len(docs)} documents chargés")

    docs = clean_documents(docs)
    chunks = chunk_documents(docs)
    print(f" {len(chunks)} chunks créés")

    db = build_vector_db(chunks)
    print("Vector DB prête")

    llm = load_llm()
    print(" LLM chargé")

    print("\n Pose ta question ('exit' pour quitter)")
    while True:
        question = input(" Question > ")
        if question.lower() in ["exit", "quit"]:
            print("👋 Fin")
            break

        answer = ask_question(question, llm, db)
        print("\n Réponse :")
        print(answer)
        print("-" * 60)


# =============================
if __name__ == "__main__":
    main()
